var Service = (function () {
    function Service() {
    }
    Service.initialize = function () {
        browser.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (request.action == 'get-options') {
                var o = {
                    'isAutoEnabled': App.isAutoEnabled,
                    'isSepia': App.isSepia
                };
                sendResponse(o);
            }
            else if (request.action == 'page-action') {
            }
            return true;
        });
        browser.contextMenus.create({
            id: "colorless-menu",
            title: "Toggle colors"
        });
        browser.contextMenus.onClicked.addListener(function (info, tab) {
            if (info.menuItemId == "colorless-menu") {
                browser.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    browser.tabs.sendMessage(tabs[0].id, {
                        'command': 'toggle'
                    });
                });
            }
        });
    };
    return Service;
}());
Service.initialize();
